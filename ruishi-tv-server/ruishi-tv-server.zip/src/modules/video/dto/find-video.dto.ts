export class FindByCategoryDto {
  category: number[];
}
