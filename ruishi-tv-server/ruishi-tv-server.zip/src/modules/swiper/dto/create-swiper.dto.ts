export class CreateSwiperDto {
  url: string;
  title: string;
  video_id: number;
}
