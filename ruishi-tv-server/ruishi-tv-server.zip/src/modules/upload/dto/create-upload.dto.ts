export class CreateUploadDto {}

export class FileDto {
  filename: string;
  path: string;
}
